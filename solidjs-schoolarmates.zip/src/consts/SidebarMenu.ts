const SidebarMenu = [
  { title: "Dashboard", Icon: "Category", Type: "MENU", link: "/", role: "any" },
  { title: "", Icon: "", Type: "DIVIDER", link: "", role: "any"},
  { title: "Student", Icon: "Docs", Type: "MENU", link: "/student", role: "any" },
  { title: "Schoolarship", Icon: "Brief", Type: "MENU", link: "/schoolarship", role: "any" },
  { title: "University", Icon: "uni", Type: "MENU", link: "/university", role: "any" },
  { title: "", Icon: "", Type: "DIVIDER", link: "", role: "admin"},
  { title: "User", Icon: "User", Type: "MENU", link: "/user", role: "admin" },
]

export default SidebarMenu;